package com.nexo.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF090911)
private val Panel = Color(0xFF171725)
private val Purple = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF50DDF5)
private val TextMain = Color(0xFFF4F3FF)
private val TextMuted = Color(0xFFAAA8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        AppContextHolder.activity = this
        FirebaseApp.initializeApp(this)
        setContent { NexoApp() }
    }
}

@Composable
private fun NexoApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("Подключи Firebase, чтобы включить SMS и облачные чаты.") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Cyan, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            if (signedIn) ChatScreen(onSignOut = { auth.signOut(); signedIn = false })
            else AuthScreen(
                notice = notice,
                onRequestCode = { phone ->
                    if (FirebaseApp.getApps(AppContextHolder.context).isEmpty()) {
                        notice = "Firebase ещё не настроен. Добавь app/google-services.json и подключи Firebase Authentication."
                    } else {
                        val options = PhoneAuthOptions.newBuilder(auth)
                            .setPhoneNumber(phone)
                            .setTimeout(60L, TimeUnit.SECONDS)
                            .setActivity(AppContextHolder.activity ?: return@AuthScreen)
                            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                    auth.signInWithCredential(credential).addOnSuccessListener { signedIn = true }
                                        .addOnFailureListener { notice = it.localizedMessage ?: "Не удалось войти" }
                                }
                                override fun onVerificationFailed(e: com.google.firebase.FirebaseException) { notice = e.localizedMessage ?: "Ошибка отправки SMS" }
                                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                                    verificationId = id
                                    notice = "Код отправлен. Введите его в поле ниже."
                                }
                            }).build()
                        PhoneAuthProvider.verifyPhoneNumber(options)
                    }
                },
                onVerifyCode = { code ->
                    val id = verificationId
                    if (id == null) notice = "Сначала запроси SMS-код."
                    else auth.signInWithCredential(PhoneAuthProvider.getCredential(id, code))
                        .addOnSuccessListener { signedIn = true }
                        .addOnFailureListener { notice = it.localizedMessage ?: "Неверный код" }
                }
            )
        }
    }
}

// Activity/context holder is set by a lifecycle callback in the activity below.
private object AppContextHolder {
    lateinit var context: android.content.Context
    var activity: android.app.Activity? = null
}

@Composable
private fun AuthScreen(notice: String, onRequestCode: (String) -> Unit, onVerifyCode: (String) -> Unit) {
    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
            Text("N", color = Cyan, fontSize = 42.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(18.dp))
        Text("NEXO", fontSize = 32.sp, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = 5.sp)
        Text("Общение без границ", color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Номер телефона, например +79991234567") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(onClick = { onRequestCode(phone.trim()) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Получить SMS-код") }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Код из SMS") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { onVerifyCode(code.trim()) }, modifier = Modifier.fillMaxWidth()) { Text("Подтвердить номер") }
        Spacer(Modifier.height(16.dp))
        Text(notice, color = TextMuted, fontSize = 12.sp)
    }
}

private data class ChatMessage(val id: String = "", val senderId: String = "", val text: String = "", val createdAt: Long = 0L)

@Composable
private fun ChatScreen(onSignOut: () -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var recipientUid by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var status by remember { mutableStateOf("Введи UID собеседника, чтобы открыть тестовый чат.") }
    val me = auth.currentUser?.uid.orEmpty()
    val chatId = remember(me, recipientUid) { listOf(me, recipientUid.trim()).filter { it.isNotBlank() }.sorted().joinToString("_") }

    DisposableEffect(chatId, me, recipientUid) {
        var registration: com.google.firebase.firestore.ListenerRegistration? = null
        if (me.isNotBlank() && recipientUid.isNotBlank() && recipientUid.trim() != me) {
            registration = db.collection("chats").document(chatId).collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING).limitToLast(200)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) status = error.localizedMessage ?: "Не удалось загрузить сообщения"
                    else messages = snapshot?.documents?.map { d -> ChatMessage(d.id, d.getString("senderId") ?: "", d.getString("text") ?: "", d.getLong("createdAt") ?: 0L) } ?: emptyList()
                }
        }
        onDispose { registration?.remove() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("NEXO", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("ТВОИ ЛЮДИ. ТВОИ ЧАТЫ.", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
            }
            TextButton(onClick = onSignOut) { Text("Выйти") }
        }
        Spacer(Modifier.height(16.dp))
        Text("Твой UID: $me", color = TextMuted, fontSize = 11.sp)
        OutlinedTextField(value = recipientUid, onValueChange = { recipientUid = it.trim() }, label = { Text("UID собеседника") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text(status, color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = false, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { message ->
                val mine = message.senderId == me
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (mine) Color(0xFF33285A) else Panel, shape = RoundedCornerShape(16.dp)) {
                        Text(message.text, Modifier.widthIn(max = 280.dp).padding(horizontal = 14.dp, vertical = 10.dp), color = TextMain)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Написать сообщение…") }, maxLines = 4)
            IconButton(onClick = {
                val body = draft.trim()
                val to = recipientUid.trim()
                if (body.isNotEmpty() && to.isNotEmpty() && to != me && me.isNotBlank()) {
                    val data = mapOf("senderId" to me, "recipientId" to to, "text" to body, "createdAt" to System.currentTimeMillis())
                    db.collection("chats").document(chatId).collection("messages").add(data)
                        .addOnSuccessListener { draft = "" }
                        .addOnFailureListener { status = it.localizedMessage ?: "Не удалось отправить" }
                } else status = "Укажи UID другого пользователя и введи сообщение."
            }) { Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Cyan) }
        }
        Text("MVP · сообщения хранятся в Firestore после настройки правил доступа", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
    }
}
